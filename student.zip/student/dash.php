<?php
define('TITLE', 'Dashboard');
define('PAGE', 'dash');
include('include/header.php');
include('include/navbar_student.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title><?php echo TITLE ?></title>
    
	<!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
    
</head>
<body>


	<!-- START Dashboard Stat Cards -->

<div class="col-sm-9 col-md-10">
		<div class="row mx-5 justify-content-center text-center">

			<div class="col-sm-4 mt-5">
				<div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
					<div class="card-header">Notice</div>
					<div class="card-body">
						<h4 class="card-title">
							<?php echo "Number of Notice"; ?>
						</h4>
						<a class="btn text-white" href="#">View</a>
					</div>
				</div>
			</div>

			<div class="col-sm-4 mt-5">
				<div class="card text-white bg-success mb-3" style="max-width: 18rem;">
					<div class="card-header">Experiments</div>
					<div class="card-body">
						<h4 class="card-title">
							<?php echo "Number of Experiments"; ?>
						</h4>
						<a class="btn text-white" href="exp.php">View</a>
					</div>
				</div>
			</div>

			<div class="col-sm-4 mt-5">
				<div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
					<div class="card-header">Assginments</div>
					<div class="card-body">
						<h4 class="card-title">
							<?php echo "Number of Assginments"; ?>
						</h4>
						<a class="btn text-white" href="assgin.php">View</a>
					</div>
				</div>
            </div>
            

		</div>

		<div class="row mx-5 text-center">

			<div class="col-sm-9 mt-5  col-md-12">
				<div class="row">
					<div class="col-sm-9 mt-5">

						<!-- Section after cards -->
					</div>
				</div>
			</div>

		</div>
		<!-- END Dashboard Stat Cards -->
    
</body>
</html>