<?php
define('TITLE', 'Manage');
define('PAGE', 'manage');
include('include/header.php');
include('include/navbar_student.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo TITLE ?></title>


    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
</head>

<body>
    <!-- START UPLOAD FORM -->
    <div class="col-sm-9 col-md-5 p-md-5  ">

        <div class="row justify-content-center bg-light ">
            <div class="col-sm-12 col-md-11 ">

                <h3 class="text-center p-mt-4 mt-3">
                    Experiments</h3>

                <table class="table table-responsive-sm  text-center mt-5 jumbotron">
                    <thead class="text-center">
                        <tr>

                            <th class="text-center" scope="col">Exp. No.</th>
                            <th class="text-center" scope="col">Title</th>
                            <th class="text-center" scope="col">Last Date</th>
                            <th class="text-center" scope="col">Upload</th>

                        </tr>
                    </thead>
                    <tbody>
                        <td>1</td>
                        <td>C# Programmig</td>
                        <td>19-10-2022</td>
                        <td> <button type="upload" class="btn btn-info btn-sm  btn-block shadow-sm"
                                name="upload">Upload</button></td>
                    </tbody>
                </table>


            </div>
        </div>

    </div>
    <!-- END UPLOAD FORM -->


    <!-- DISPLAY TOOL LIST START -->
    <div class="col-sm-9 col-md-5 p-md-5  ">
        <div class="row justify-content-center bg-light ">
            <div class="col-sm-12 col-md-11 ">

                <h3 class="text-center p-mt-4 mt-3">Assginments</h3>
                <table class="table table-responsive-sm  text-center mt-5 jumbotron">
                    <thead class="text-center">
                        <tr>

                            <th class="text-center" scope="col">Sr. No.</th>
                            <th class="text-center" scope="col">Title</th>
                            <th class="text-center" scope="col">Last Date</th>
                            <th class="text-center" scope="col">Upload</th>

                        </tr>
                    </thead>
                    <tbody>
                        <td>1</td>
                        <td>JAVA Programmig</td>
                        <td>13-9-2022</td>
                        <td> <button type="upload" class="btn btn-info btn-sm  btn-block shadow-sm"
                                name="upload">Upload</button></td>
                    </tbody>
                </table>

            </div>
        </div>

    </div>

</body>

</html>