<nav class="navbar navbar-dark fixed-top bg-info p-0 shadow">
    
    <div class="navbar-brand align-content-sm-stretch col-md-2 mr-0">Smart Learn</div>
</nav>