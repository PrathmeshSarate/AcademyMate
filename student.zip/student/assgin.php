<?php
define('TITLE', 'Assginments');
define('PAGE', 'assginments');
include('include/header.php');
include('include/navbar_student.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo TITLE ?></title>


    
	<!-- Custom CSS -->
	<link rel="stylesheet" href="css/custom.css">
</head>
<body>


<div class="col-md-10">
    <div class="col-md-12  mt-5">
                
                <h1 class="heading text-center  ">Assginments</h1>
            
            <?php
            // include '../dbcon.php';

            // $query = "SELECT * FROM `user_order`";

            // $result = mysqli_query($conn, $query);


            // if (mysqli_num_rows($result) > 0) {

                echo '<table class="table table-responsive-sm  text-center mt-5 jumbotron">
    <thead class="text-center">
     <tr >
      
      <th class="text-center" scope="col">Sr. No.</th>
      <th class="text-center" scope="col">Title</th>
      <th class="text-center" scope="col">Description</th>
      <th class="text-center" scope="col">Dates</th>
      <th class="text-center" scope="col">View</th>
      <th class="text-center" scope="col">Download</th>
     </tr>
    </thead>
    <tbody>';
//                 $counter = 1;
//                 while ($row = $result->fetch_assoc()) {
//                     $id = $row['id'];
//                     echo '<tr>';



//                     echo '<td>' . $counter . '</td>';
                    
//                     echo '<td>' . $row["order_id"] . '</td>';
                    
//                     echo '<td>' . $row["fname"] . '</td>';
                    
                    
                    
//                     echo '<td>' . $row["p_type"] . '</td>';
                    
//                     echo '<td><button data-id='.$id.' class="userinfo">Info</button></td>';
                    
//                     echo '<td>' . $row["status"] . '</td>';
                    
//                     echo '<td>
//                                 <form action="" method="POST" class="d-inline">
//                                     <input type="hidden" name="id" value='. $row["id"] .'>
//                                         <button type="submit" class="btn btn-success" name="correct" value="correct">
//                                             <i class="fas fa-check"></i>
//                                         </button>
//                                 </form> 
                                
//                                 <form action="" method="POST" class="d-inline">
//                                     <input type="hidden" name="id" value='. $row["id"] .'>
//                                         <button type="submit" class="btn btn-danger" name="cancel" value="cancel">
//                                         <i class="fas fa-times"></i>
//                                         </button>
//                                 </form>
//                             </td>
//       </tr>';


//                     echo '</tr>';
//                     $counter++;
//                 }
//                 echo '</tbody>
//    </table>';
   ?>
  

 <?php
// } else {
//                 echo "0 Result";
//             }





            ?>



        </div>
    </div>
    
</body>
</html>